docker stop pool  ; docker rm pool
