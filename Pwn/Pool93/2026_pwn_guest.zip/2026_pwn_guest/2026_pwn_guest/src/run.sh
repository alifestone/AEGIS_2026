#!/bin/bash
cd /home/aegis
exec /usr/bin/timeout -s KILL 180s /usr/bin/qemu-ppc64 -L /usr/powerpc64-linux-gnu ./pool93
