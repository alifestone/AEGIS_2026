#!/bin/bash
set -e
docker build -t pool .
docker run --name pool -p 4496:4496 pool
