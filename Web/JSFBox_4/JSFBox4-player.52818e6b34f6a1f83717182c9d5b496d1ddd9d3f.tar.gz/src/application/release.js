'use strict';

const { RequestError } = require('../errors');

const COMPLETE_TRAIL = Object.freeze(['observed', 'distributed', 'cataloged', 'delivered']);

function requireRepresentation(value) {
    if (typeof value !== 'string') throw new RequestError(400, 'Data required.');
    return value;
}

function createReleaseModule(options) {
    const { cache, completion, documents, journal, lifecycle, proof } = options;

    function attest({ state, dto }) {
        lifecycle.requireStage(state, 'reviewed');
        if (!journal.hasTrail(state, ['observed'])) throw new RequestError(409, 'Sequence rejected.');
        const representation = requireRepresentation(dto.observation.representation);
        const witness = journal.verifyWitness(dto.observation.credential, state, 1);
        if (witness.digest !== journal.digest(representation)
            || !documents.match(state.document, witness.profile, {
                tag: witness.tag,
                body: representation,
            })) {
            throw new RequestError(403, 'Data rejected.');
        }
        return { result: { credential: journal.issueApproval(state) } };
    }

    async function release({ state, dto }) {
        const representation = requireRepresentation(dto.artifact.representation);
        const approval = journal.verifyApproval(dto.credentials.primary, state);
        if (state.stage === 'reviewed' && journal.hasTrail(state, ['observed'])) {
            if (!documents.match(state.document, approval.profile, {
                tag: approval.tag,
                body: representation,
            })) {
                throw new RequestError(403, 'Data rejected.');
            }
            return { result: { kind: 'accepted' } };
        }
        if (state.stage !== 'released' || !journal.hasTrail(state, COMPLETE_TRAIL)) {
            throw new RequestError(409, 'Sequence rejected.');
        }
        const checkpoint = journal.verifyWitness(dto.credentials.checkpoint, state, 2);
        const terminal = journal.verifyWitness(dto.credentials.terminal, state, 4);
        const stored = cache.read(state.cache);
        const received = journal.at(state, 1);
        const cataloged = journal.at(state, 2);
        if (checkpoint.digest !== received.digest || checkpoint.profile !== received.profile
            || terminal.digest !== journal.digest(representation)
            || stored.body !== representation
            || stored.entityProfile !== received.profile || stored.entityTag !== received.tag
            || stored.metadataProfile !== cataloged.profile || stored.headers.etag !== cataloged.tag
            || !documents.match(state.document, stored.entityProfile, {
                tag: stored.entityTag,
                body: representation,
            })) {
            throw new RequestError(403, 'Data rejected.');
        }
        await proof.verify(journal.proofContext(state), dto.artifact.answer);
        return { result: { kind: 'complete', value: completion.deliver() } };
    }

    return Object.freeze({ attest, release });
}

module.exports = { createReleaseModule };
