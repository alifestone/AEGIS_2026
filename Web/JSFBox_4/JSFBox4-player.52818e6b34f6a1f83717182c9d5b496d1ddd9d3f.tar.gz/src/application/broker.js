'use strict';

const { RequestError } = require('../errors');

function createBroker(sessions, descriptors) {
    async function execute(binding, dto) {
        const descriptor = descriptors[binding];
        if (!descriptor) throw new RequestError(404, 'Not found.');

        if (descriptor.mode === 'create') {
            let result;
            const created = sessions.create((workspaceId) => {
                const outcome = descriptor.handler({ dto, workspaceId });
                result = outcome.result;
                return outcome.state;
            });
            return { ...result, lease: created.lease };
        }

        const transaction = sessions.open(dto.lease);
        const outcome = await descriptor.handler({
            dto,
            state: transaction.state,
            lease: transaction.lease,
        });
        if (!outcome || !outcome.result) throw new RequestError(500, 'Internal error.');
        if (descriptor.mode === 'write') {
            return { ...outcome.result, lease: transaction.commit(outcome.state || transaction.state) };
        }
        return { ...outcome.result, lease: transaction.lease };
    }

    return Object.freeze({ execute });
}

module.exports = { createBroker };
