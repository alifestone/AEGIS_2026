'use strict';

function createControlModule(documents, lifecycle) {
    function intake({ workspaceId }) {
        const reference = documents.create();
        return {
            state: lifecycle.create(workspaceId, reference),
            result: { reference },
        };
    }

    function queue({ state }) {
        lifecycle.requireStage(state, 'draft');
        lifecycle.advance(state, 'queue');
        return { state, result: { step: state.step } };
    }

    return Object.freeze({ intake, queue });
}

module.exports = { createControlModule };
