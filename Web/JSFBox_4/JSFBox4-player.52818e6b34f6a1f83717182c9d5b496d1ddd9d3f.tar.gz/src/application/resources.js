'use strict';

const { operation } = require('../config/policies');
const { selectResourceRule } = require('../config/resources');
const { RequestError } = require('../errors');

function createResourceModule(options) {
    const { cache, journal, lifecycle, origin, proof, sessions } = options;

    async function distribute({ state, dto }) {
        lifecycle.requireStage(state, 'reviewed');
        if (!journal.hasTrail(state, ['observed'])) throw new RequestError(409, 'Sequence rejected.');
        journal.verifyApproval(dto.credentials.primary, state);
        const policy = operation('distribution');
        const source = await origin({
            reference: state.document,
            profile: policy.profile,
            method: 'GET',
        });
        state.cache = cache.capture(state.cache.identity, source);
        lifecycle.advance(state, policy.move);
        journal.append(state, policy.event, {
            profile: source.profile,
            tag: source.headers.etag,
            body: source.body,
        });
        return {
            state,
            result: {
                checkpoint: journal.issueWitness(state),
                upstream: { status: source.status },
            },
        };
    }

    async function originCapture(context, rule) {
        const policy = operation(rule.policy);
        const source = await origin({
            reference: context.state.document,
            profile: policy.profile,
            method: context.request.method,
        });
        context.state.cache = cache.capture(context.request.query, source);
        lifecycle.advance(context.state, policy.move);
        journal.append(context.state, policy.event, {
            profile: source.profile,
            tag: source.headers.etag,
            body: source.body,
        });
        return {
            state: context.state,
            cache: 'miss',
            exchange: source,
            witness: journal.issueWitness(context.state),
        };
    }

    async function metadataRevision(context, rule) {
        if (!cache.sameIdentity(context.state.cache, context.request.query)) {
            throw new RequestError(409, 'Sequence rejected.');
        }
        const policy = operation(rule.policy);
        const source = await origin({
            reference: context.state.document,
            profile: policy.profile,
            method: context.request.method,
        });
        const revised = cache.revise(context.state.cache, source);
        if (!revised) throw new RequestError(409, 'Sequence rejected.');
        context.state.cache = revised;
        lifecycle.advance(context.state, policy.move);
        const stored = cache.read(revised);
        journal.append(context.state, policy.event, {
            profile: source.profile,
            tag: source.headers.etag,
            body: stored.body,
        });
        return {
            state: context.state,
            cache: 'miss',
            exchange: source,
            witness: journal.issueWitness(context.state),
        };
    }

    async function cacheDelivery(context, rule) {
        if (!cache.reusable(context.state.cache, context.request.query)) {
            throw new RequestError(409, 'Sequence rejected.');
        }
        const policy = operation(rule.policy);
        const stored = cache.read(context.state.cache);
        lifecycle.advance(context.state, policy.move);
        journal.append(context.state, policy.event, {
            profile: stored.metadataProfile,
            tag: stored.headers.etag,
            body: stored.body,
        });
        return {
            state: context.state,
            cache: 'hit',
            exchange: {
                status: 200,
                profile: stored.metadataProfile,
                headers: stored.headers,
                body: stored.body,
            },
            witness: journal.issueWitness(context.state),
            proof: proof.issue(journal.proofContext(context.state)),
        };
    }

    async function originRead(context, rule) {
        const policy = operation(rule.policy);
        const source = await origin({
            reference: context.state.document,
            profile: policy.profile,
            method: context.request.method,
        });
        return { cache: 'miss', exchange: source };
    }

    const providers = Object.freeze({ originCapture, metadataRevision, cacheDelivery, originRead });

    async function handle(request) {
        const transaction = sessions.open(request.lease);
        const rule = selectResourceRule(request.family, request.kind, transaction.state.stage);
        const provider = rule && providers[rule.provider];
        if (!provider) throw new RequestError(409, 'Sequence rejected.');
        const result = await provider({ state: transaction.state, request }, rule);
        if (result.state) result.lease = transaction.commit(result.state);
        else result.lease = transaction.lease;
        return result;
    }

    return Object.freeze({ distribute, handle });
}

module.exports = { createResourceModule };
