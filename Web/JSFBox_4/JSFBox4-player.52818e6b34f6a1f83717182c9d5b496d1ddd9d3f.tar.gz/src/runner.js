'use strict';

const { getQuickJS: loadEngine } = require('quickjs-emscripten');

const INPUT_LIMIT = 2048;
const OUTPUT_LIMIT = 64;
const DEADLINE = 500;

function finish(value, code = 0) {
    process.stdout.write(JSON.stringify(value));
    process.exitCode = code;
}

async function readValue() {
    let input = '';
    for await (const chunk of process.stdin) {
        input += chunk;
        if (Buffer.byteLength(input) > INPUT_LIMIT) throw new Error('input');
    }
    const value = JSON.parse(input);
    if (!value || typeof value.source !== 'string') throw new Error('input');
    return value.source;
}

async function main() {
    const source = await readValue();
    const engine = await loadEngine();
    const context = engine.newContext();
    const limit = Date.now() + DEADLINE;
    context.runtime.setMemoryLimit(8 * 1024 * 1024);
    context.runtime.setMaxStackSize(512 * 1024);
    context.runtime.setInterruptHandler(() => Date.now() > limit);
    try {
        const result = context.evalCode(source, 'input.js');
        if (result.error) {
            result.error.dispose();
            return finish({ ok: false }, 1);
        }
        const value = result.value;
        try {
            if (context.typeof(value) !== 'string') return finish({ ok: false }, 1);
            const output = context.getString(value);
            if (Buffer.byteLength(output) > OUTPUT_LIMIT) return finish({ ok: false }, 1);
            return finish({ ok: true, value: output });
        } finally {
            value.dispose();
        }
    } finally {
        context.dispose();
    }
}

main().catch(() => finish({ ok: false }, 1));
