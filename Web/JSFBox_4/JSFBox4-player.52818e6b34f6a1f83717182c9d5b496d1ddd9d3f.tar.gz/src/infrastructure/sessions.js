'use strict';

const { randomUUID } = require('node:crypto');
const { RequestError } = require('../errors');

const VERSION = 1;
const CHANNEL = 'workspace-lease';

function clone(value) {
    return structuredClone(value);
}

function createSessionRepository(codec) {
    const workspaces = new Map();

    function seal(id, revision) {
        return codec.seal(CHANNEL, { version: VERSION, id, revision });
    }

    function create(factory) {
        const id = randomUUID();
        const state = factory(id);
        if (!state || state.identity?.workspaceId !== id) throw new TypeError('State rejected.');
        workspaces.set(id, { next: 1, snapshots: new Map([[0, clone(state)]]) });
        return { lease: seal(id, 0), state: clone(state) };
    }

    function open(token) {
        let pointer;
        try {
            pointer = codec.open(CHANNEL, token);
        } catch {
            throw new RequestError(400, 'State rejected.');
        }
        if (!pointer || pointer.version !== VERSION || typeof pointer.id !== 'string'
            || !Number.isSafeInteger(pointer.revision)) {
            throw new RequestError(400, 'State rejected.');
        }
        const workspace = workspaces.get(pointer.id);
        const snapshot = workspace?.snapshots.get(pointer.revision);
        if (!snapshot) throw new RequestError(400, 'State rejected.');
        let committed = false;
        return Object.freeze({
            lease: token,
            state: clone(snapshot),
            commit(next) {
                if (committed || next?.identity?.workspaceId !== pointer.id) {
                    throw new RequestError(409, 'Sequence rejected.');
                }
                committed = true;
                const revision = workspace.next++;
                workspace.snapshots.set(revision, clone(next));
                return seal(pointer.id, revision);
            },
        });
    }

    return Object.freeze({ create, open });
}

module.exports = { createSessionRepository };
