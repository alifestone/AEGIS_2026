'use strict';

const { spawn } = require('node:child_process');
const path = require('node:path');
const { RequestError } = require('../errors');

const TIMEOUT = 2000;
const OUTPUT_LIMIT = 4096;
const ACTIVE_LIMIT = 2;
const WAIT_LIMIT = 64;
let active = 0;
const waiting = [];

function acquire() {
    if (active < ACTIVE_LIMIT) {
        active += 1;
        return Promise.resolve();
    }
    if (waiting.length >= WAIT_LIMIT) {
        return Promise.reject(new RequestError(503, 'Request rejected.'));
    }
    return new Promise((resolve) => waiting.push(resolve));
}

function release() {
    const next = waiting.shift();
    if (next) next();
    else active -= 1;
}

function createEvaluator() {
    async function evaluate(source) {
        await acquire();
        return new Promise((resolve, reject) => {
            let worker;
            try {
                worker = spawn(process.execPath, [path.join(__dirname, '..', 'runner.js')], {
                    cwd: path.join(__dirname, '..'),
                    env: { NODE_ENV: 'production', PATH: process.env.PATH || '' },
                    stdio: ['pipe', 'pipe', 'pipe'],
                });
            } catch {
                release();
                reject(new RequestError(503, 'Request rejected.'));
                return;
            }
            let settled = false;
            let stdout = '';
            let stderrSize = 0;
            const finish = (error, value) => {
                if (settled) return;
                settled = true;
                clearTimeout(timer);
                release();
                if (error) reject(error);
                else resolve(value);
            };
            const timer = setTimeout(() => {
                worker.kill('SIGKILL');
                finish(new RequestError(422, 'Answer rejected.'));
            }, TIMEOUT);
            worker.once('error', () => finish(new RequestError(503, 'Request rejected.')));
            worker.stdout.on('data', (chunk) => {
                stdout += chunk;
                if (Buffer.byteLength(stdout) > OUTPUT_LIMIT) {
                    worker.kill('SIGKILL');
                    finish(new RequestError(422, 'Answer rejected.'));
                }
            });
            worker.stderr.on('data', (chunk) => {
                stderrSize += chunk.length;
                if (stderrSize > OUTPUT_LIMIT) worker.kill('SIGKILL');
            });
            worker.once('close', (code) => {
                if (settled) return;
                if (code !== 0) return finish(new RequestError(422, 'Answer rejected.'));
                try {
                    const result = JSON.parse(stdout);
                    if (!result || result.ok !== true || typeof result.value !== 'string') {
                        return finish(new RequestError(422, 'Answer rejected.'));
                    }
                    return finish(null, result.value);
                } catch {
                    return finish(new RequestError(422, 'Answer rejected.'));
                }
            });
            worker.stdin.once('error', () => finish(new RequestError(503, 'Request rejected.')));
            worker.stdin.end(JSON.stringify({ source }));
        });
    }

    return Object.freeze({ evaluate });
}

module.exports = { createEvaluator };
