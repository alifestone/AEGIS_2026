'use strict';

const Policy = require('http-cache-semantics');
const { CACHE_EQUIVALENCE } = require('../config/policies');

function normalize(headers) {
    return Object.fromEntries(Object.entries(headers || {}).map(([name, value]) => [
        name.toLowerCase(), String(value),
    ]));
}

function shapeRequest(request) {
    if (!request || request.method !== 'GET' || typeof request.url !== 'string') {
        throw new TypeError('Request rejected.');
    }
    return { url: request.url, method: 'GET', headers: normalize(request.headers) };
}

function shapeResponse(exchange) {
    if (!exchange || exchange.status !== 200 || !exchange.headers) {
        throw new TypeError('Record rejected.');
    }
    return { status: 200, headers: normalize(exchange.headers) };
}

function compile(identity, metadata) {
    const policy = new Policy(identity, metadata, { shared: true });
    if (!policy.storable()) throw new Error('Record rejected.');
    return policy.toObject();
}

function isEntry(value) {
    return Boolean(value && typeof value === 'object' && value.identity?.method === 'GET'
        && typeof value.identity.url === 'string' && value.identity.headers
        && value.facets?.entity && typeof value.facets.entity.body === 'string'
        && typeof value.facets.entity.profile === 'string' && typeof value.facets.entity.tag === 'string'
        && value.facets.metadata?.status === 200 && value.facets.metadata.headers
        && typeof value.facets.metadata.profile === 'string'
        && value.facets.policy && typeof value.facets.policy === 'object');
}

function applyFacetPatch(entry, patch) {
    return { identity: entry.identity, facets: { ...entry.facets, ...patch } };
}

function createFacetCache() {
    function capture(request, exchange) {
        if (typeof exchange?.body !== 'string' || typeof exchange?.profile !== 'string') {
            throw new TypeError('Record rejected.');
        }
        const identity = shapeRequest(request);
        const metadata = shapeResponse(exchange);
        return {
            identity,
            facets: {
                entity: {
                    body: exchange.body,
                    profile: exchange.profile,
                    tag: metadata.headers.etag,
                },
                metadata: { ...metadata, profile: exchange.profile },
                policy: compile(identity, metadata),
            },
        };
    }

    function revise(entry, exchange) {
        if (!isEntry(entry) || typeof exchange?.profile !== 'string') return null;
        let metadata;
        try {
            metadata = shapeResponse(exchange);
        } catch {
            return null;
        }
        const current = normalize(entry.facets.metadata.headers);
        const next = normalize(metadata.headers);
        if (!CACHE_EQUIVALENCE.every((name) => (
            typeof current[name] === 'string' && current[name] === next[name]
        ))) {
            return null;
        }
        try {
            return applyFacetPatch(entry, {
                metadata: { ...metadata, profile: exchange.profile },
                policy: compile(entry.identity, metadata),
            });
        } catch {
            return null;
        }
    }

    function reusable(entry, request) {
        if (!isEntry(entry) || !request || request.method !== 'GET') return false;
        try {
            return Policy.fromObject(entry.facets.policy).satisfiesWithoutRevalidation({
                url: request.url,
                method: 'GET',
                headers: normalize(request.headers),
            });
        } catch {
            return false;
        }
    }

    function sameIdentity(entry, request) {
        if (!isEntry(entry)) return false;
        try {
            return JSON.stringify(entry.identity) === JSON.stringify(shapeRequest(request));
        } catch {
            return false;
        }
    }

    function read(entry) {
        if (!isEntry(entry)) throw new TypeError('Record rejected.');
        return Object.freeze({
            headers: entry.facets.metadata.headers,
            body: entry.facets.entity.body,
            entityProfile: entry.facets.entity.profile,
            entityTag: entry.facets.entity.tag,
            metadataProfile: entry.facets.metadata.profile,
        });
    }

    return Object.freeze({ capture, isEntry, read, reusable, revise, sameIdentity });
}

module.exports = { createFacetCache };
