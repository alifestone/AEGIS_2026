'use strict';

const { createCipheriv, createDecipheriv, randomBytes } = require('node:crypto');

const VERSION = 'v1';
const MAX_DATA = 16 * 1024;
const MAX_TOKEN = 24 * 1024;

function requireKey(key) {
    if (!Buffer.isBuffer(key) || key.length !== 32) throw new TypeError('Key rejected.');
}

function createEnvelopeCodec(key = randomBytes(32)) {
    requireKey(key);

    function seal(channel, value) {
        if (typeof channel !== 'string' || channel.length === 0) throw new Error('Channel rejected.');
        const plaintext = Buffer.from(JSON.stringify(value));
        if (plaintext.length > MAX_DATA) throw new Error('Data rejected.');
        const nonce = randomBytes(12);
        const cipher = createCipheriv('aes-256-gcm', key, nonce);
        cipher.setAAD(Buffer.from(`jsfbox4:${channel}:${VERSION}`));
        const ciphertext = Buffer.concat([cipher.update(plaintext), cipher.final()]);
        const tag = cipher.getAuthTag();
        return [VERSION, nonce.toString('base64url'), tag.toString('base64url'), ciphertext.toString('base64url')].join('.');
    }

    function open(channel, token) {
        if (typeof channel !== 'string' || channel.length === 0
            || typeof token !== 'string' || token.length === 0
            || Buffer.byteLength(token) > MAX_TOKEN) {
            throw new Error('Token rejected.');
        }
        const parts = token.split('.');
        if (parts.length !== 4 || parts[0] !== VERSION) throw new Error('Token rejected.');
        try {
            const nonce = Buffer.from(parts[1], 'base64url');
            const tag = Buffer.from(parts[2], 'base64url');
            const ciphertext = Buffer.from(parts[3], 'base64url');
            if (nonce.length !== 12 || tag.length !== 16 || ciphertext.length > MAX_DATA) {
                throw new Error('Token rejected.');
            }
            const decipher = createDecipheriv('aes-256-gcm', key, nonce);
            decipher.setAAD(Buffer.from(`jsfbox4:${channel}:${VERSION}`));
            decipher.setAuthTag(tag);
            const plaintext = Buffer.concat([decipher.update(ciphertext), decipher.final()]);
            return JSON.parse(plaintext.toString('utf8'));
        } catch {
            throw new Error('Token rejected.');
        }
    }

    return Object.freeze({ open, seal });
}

module.exports = { createEnvelopeCodec };
