'use strict';

function createCompletionProvider(value) {
    if (typeof value !== 'string' || value.length === 0) throw new TypeError('Value required.');
    return Object.freeze({ deliver: () => value });
}

module.exports = { createCompletionProvider };
