'use strict';

const http = require('node:http');
const { randomBytes } = require('node:crypto');
const { readFileSync, unlinkSync } = require('node:fs');
const path = require('node:path');
const { createEnvelopeCodec } = require('./infrastructure/crypto');
const { createSessionRepository } = require('./infrastructure/sessions');
const { createFacetCache } = require('./infrastructure/cache');
const { createEvaluator } = require('./infrastructure/evaluator');
const { createCompletionProvider } = require('./infrastructure/completion');
const { createDocumentRepository } = require('./domain/documents');
const { createJournal } = require('./domain/journal');
const { createLifecycle } = require('./domain/lifecycle');
const { createProofModule } = require('./domain/proof');
const { createControlModule } = require('./application/control');
const { createResourceModule } = require('./application/resources');
const { createReleaseModule } = require('./application/release');
const { createBroker } = require('./application/broker');
const { createProjectionModule } = require('./adapters/projection');
const { createDirectOrigin, createOriginApp, createOriginClient } = require('./adapters/origin');
const { createHttpApp } = require('./adapters/http');

const PORT = 1024;
const LOCAL_PORT = 1025;
const STATIC_ROOT = path.join(__dirname, 'static');

function requireValue(options) {
    if (typeof options.value !== 'string' || options.value.length === 0) {
        throw new TypeError('Value required.');
    }
}

function createKernel(options, codec, documents, sessions, origin) {
    const journal = createJournal(codec);
    const lifecycle = createLifecycle(journal);
    const cache = createFacetCache();
    const evaluator = createEvaluator();
    const proof = createProofModule(codec, evaluator);
    const completion = createCompletionProvider(options.value);
    const control = createControlModule(documents, lifecycle);
    const resources = createResourceModule({
        cache,
        journal,
        lifecycle,
        origin,
        proof,
        sessions,
    });
    const release = createReleaseModule({
        cache,
        completion,
        documents,
        journal,
        lifecycle,
        proof,
    });
    const projection = createProjectionModule();
    const broker = createBroker(sessions, Object.freeze({
        intake: Object.freeze({ mode: 'create', handler: control.intake }),
        queue: Object.freeze({ mode: 'write', handler: control.queue }),
        attest: Object.freeze({ mode: 'read', handler: release.attest }),
        distribute: Object.freeze({ mode: 'write', handler: resources.distribute }),
        release: Object.freeze({ mode: 'read', handler: release.release }),
        project: Object.freeze({ mode: 'read', handler: projection.project }),
        export: Object.freeze({ mode: 'read', handler: projection.exportRecord }),
    }));
    return { app: createHttpApp({ broker, resources, staticRoot: STATIC_ROOT }), resources };
}

function createApp(options = {}) {
    requireValue(options);
    const codec = createEnvelopeCodec(options.tokenKey || randomBytes(32));
    const documents = createDocumentRepository();
    const sessions = createSessionRepository(codec);
    return createKernel(options, codec, documents, sessions, createDirectOrigin(documents)).app;
}

function listen(server, port, host) {
    return new Promise((resolve, reject) => {
        server.once('error', reject);
        server.listen(port, host, () => {
            server.off('error', reject);
            resolve(server);
        });
    });
}

function close(server) {
    return new Promise((resolve, reject) => {
        server.close((error) => error ? reject(error) : resolve());
    });
}

function createRuntime(options = {}) {
    requireValue(options);
    const codec = createEnvelopeCodec(options.tokenKey || randomBytes(32));
    const documents = createDocumentRepository();
    const sessions = createSessionRepository(codec);
    const localApp = createOriginApp(codec, documents);
    const localServer = http.createServer(localApp);
    const publicPort = options.port ?? PORT;
    let localPort = options.localPort ?? LOCAL_PORT;
    const kernel = createKernel(
        options,
        codec,
        documents,
        sessions,
        createOriginClient(() => localPort, codec),
    );
    const publicServer = http.createServer(kernel.app);
    return Object.freeze({
        app: kernel.app,
        localApp,
        async listen() {
            await listen(localServer, localPort, '127.0.0.1');
            localPort = localServer.address().port;
            try {
                await listen(publicServer, publicPort, '0.0.0.0');
            } catch (error) {
                await close(localServer);
                throw error;
            }
            return publicServer;
        },
        async close() {
            await Promise.all([close(publicServer), close(localServer)]);
        },
        publicServer,
        localServer,
    });
}

function readRuntimeValue(filename = process.env.FLAG_FILE || '/run/jsfbox/flag') {
    const value = readFileSync(filename, 'utf8').replace(/\r?\n$/, '');
    unlinkSync(filename);
    delete process.env.FLAG_FILE;
    if (!value) throw new Error('Value required.');
    return value;
}

if (require.main === module) {
    const value = readRuntimeValue();
    const runtime = createRuntime({ value });
    runtime.listen()
        .then(() => console.log(`Listening on http://127.0.0.1:${PORT}`))
        .catch((error) => {
            console.error(error.message);
            process.exitCode = 1;
        });
}

module.exports = { createApp, createRuntime, readRuntimeValue };
