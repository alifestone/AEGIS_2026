'use strict';

const RULES = Object.freeze([
    Object.freeze({ family: 'current', kind: 'representation', stage: 'circulating', provider: 'originCapture', policy: 'observation' }),
    Object.freeze({ family: 'current', kind: 'metadata', stage: 'distributed', provider: 'metadataRevision', policy: 'catalog' }),
    Object.freeze({ family: 'current', kind: 'representation', stage: 'cataloged', provider: 'cacheDelivery', policy: 'delivery' }),
    Object.freeze({ family: 'archive', kind: 'representation', stage: '*', provider: 'originRead', policy: 'archive' }),
    Object.freeze({ family: 'archive', kind: 'metadata', stage: '*', provider: 'originRead', policy: 'archive' }),
]);

function selectResourceRule(family, kind, stage) {
    return RULES.find((rule) => rule.family === family && rule.kind === kind
        && (rule.stage === '*' || rule.stage === stage)) || null;
}

module.exports = { selectResourceRule };
