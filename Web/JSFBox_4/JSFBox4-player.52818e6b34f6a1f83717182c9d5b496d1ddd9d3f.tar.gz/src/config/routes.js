'use strict';

const CONTROL_ROUTES = Object.freeze([
    Object.freeze({ path: '/api/session', name: 'session' }),
    Object.freeze({ path: '/api/approve', name: 'approve' }),
    Object.freeze({ path: '/api/confirm', name: 'confirm' }),
    Object.freeze({ path: '/api/sync', name: 'sync' }),
    Object.freeze({ path: '/api/publish', name: 'publish' }),
    Object.freeze({ path: '/api/preview', name: 'preview' }),
    Object.freeze({ path: '/api/export', name: 'export' }),
]);

const RESOURCE_ROUTES = Object.freeze([
    Object.freeze({ path: '/w/current', name: 'current' }),
    Object.freeze({ path: '/w/archive', name: 'archive' }),
]);

module.exports = { CONTROL_ROUTES, RESOURCE_ROUTES };
