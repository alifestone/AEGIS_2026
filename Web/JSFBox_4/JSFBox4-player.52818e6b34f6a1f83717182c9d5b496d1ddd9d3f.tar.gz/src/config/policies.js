'use strict';

const OPERATIONS = Object.freeze({
    observation: Object.freeze({ profile: 'review', event: 'observed', move: 'observe' }),
    distribution: Object.freeze({ profile: 'distribution', event: 'distributed', move: 'stage' }),
    catalog: Object.freeze({ profile: 'review', event: 'cataloged', move: 'catalog' }),
    delivery: Object.freeze({ event: 'delivered', move: 'deliver' }),
    archive: Object.freeze({ profile: 'archive' }),
});

const CACHE_EQUIVALENCE = Object.freeze(['last-modified', 'content-length']);
const INPUT_LIMITS = Object.freeze({ language: 128, selector: 128 });

function operation(name) {
    const value = OPERATIONS[name];
    if (!value) throw new TypeError('Operation rejected.');
    return value;
}

module.exports = { CACHE_EQUIVALENCE, INPUT_LIMITS, operation };
