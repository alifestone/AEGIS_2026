'use strict';

const CONTROLS = Object.freeze({
    session: Object.freeze({ binding: 'intake', input: 'empty', output: 'session', status: 201 }),
    approve: Object.freeze({ binding: 'queue', input: 'lease', output: 'progress' }),
    confirm: Object.freeze({ binding: 'attest', input: 'observation', output: 'approval' }),
    sync: Object.freeze({ binding: 'distribute', input: 'approval', output: 'distribution' }),
    publish: Object.freeze({ binding: 'release', input: 'submission', output: 'decision' }),
    preview: Object.freeze({ binding: 'project', input: 'projection', output: 'projection' }),
    export: Object.freeze({ binding: 'export', input: 'export', output: 'export' }),
});

const RESOURCES = Object.freeze({
    current: Object.freeze({ family: 'current' }),
    archive: Object.freeze({ family: 'archive' }),
});

function controlBinding(name) {
    const value = CONTROLS[name];
    if (!value) throw new TypeError('Route rejected.');
    return value;
}

function resourceBinding(name) {
    const value = RESOURCES[name];
    if (!value) throw new TypeError('Route rejected.');
    return value;
}

module.exports = { controlBinding, resourceBinding };
