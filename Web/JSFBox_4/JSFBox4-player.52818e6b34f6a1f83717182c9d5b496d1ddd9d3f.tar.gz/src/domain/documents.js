'use strict';

const { createHash, randomBytes, randomUUID } = require('node:crypto');

const FIXED_DATE = 'Wed, 01 Jan 2025 00:00:00 GMT';
const WIDTH = 768;
const SCHEMES = Object.freeze([
    Object.freeze({
        profile: 'review',
        mode: 'a',
        cacheControl: 'public, max-age=60',
        mediaType: 'application/vnd.jsfbox.a+json; charset=utf-8',
        weak: false,
    }),
    Object.freeze({
        profile: 'distribution',
        mode: 'b',
        cacheControl: 'public, max-age=0, must-revalidate',
        mediaType: 'application/vnd.jsfbox.b+json; charset=utf-8',
        weak: true,
    }),
    Object.freeze({
        profile: 'archive',
        mode: 'c',
        cacheControl: 'public, max-age=120',
        mediaType: 'application/vnd.jsfbox.c+json; charset=utf-8',
        weak: false,
    }),
]);

function hash(value) {
    return createHash('sha256').update(value).digest('base64url');
}

function pack(value) {
    const empty = JSON.stringify({ ...value, padding: '' });
    const count = WIDTH - Buffer.byteLength(empty);
    if (count < 0) throw new Error('Record rejected.');
    const body = JSON.stringify({ ...value, padding: ' '.repeat(count) });
    if (Buffer.byteLength(body) !== WIDTH) throw new Error('Record rejected.');
    return body;
}

function makeTag(id, revision, scheme) {
    const opaque = `${scheme.mode}-${hash(`${id}:${revision}:${scheme.mode}`).slice(0, 24)}`;
    return scheme.weak ? `W/"${opaque}"` : `"${opaque}"`;
}

function createDocumentRepository() {
    const records = new Map();

    function create() {
        const id = randomUUID();
        const revision = 1;
        const label = 'Quarterly operations notes';
        const data = [
            'Approved summary.',
            randomBytes(24).toString('base64url'),
            `Archive ${hash(id).slice(0, 16)}`,
        ];
        const variants = SCHEMES.map((scheme, index) => Object.freeze({
            profile: scheme.profile,
            tag: makeTag(id, revision, scheme),
            representation: pack({ id, revision, mode: scheme.mode, label, data: data[index] }),
        }));
        records.set(id, Object.freeze({ id, revision, variants: Object.freeze(variants) }));
        return Object.freeze({ id, revision });
    }

    function load(reference) {
        if (!reference || typeof reference.id !== 'string' || !Number.isSafeInteger(reference.revision)) {
            throw new TypeError('Record rejected.');
        }
        const record = records.get(reference.id);
        if (!record || record.revision !== reference.revision) throw new TypeError('Record rejected.');
        return record;
    }

    function resolve(reference, profile) {
        const record = load(reference);
        const schemeIndex = SCHEMES.findIndex((scheme) => scheme.profile === profile);
        if (schemeIndex < 0) throw new TypeError('Request rejected.');
        return { record, scheme: SCHEMES[schemeIndex], variant: record.variants[schemeIndex] };
    }

    function headers(reference, profile) {
        const { scheme, variant } = resolve(reference, profile);
        return {
            'cache-control': scheme.cacheControl,
            'content-length': String(WIDTH),
            'content-type': scheme.mediaType,
            etag: variant.tag,
            'last-modified': FIXED_DATE,
            vary: 'Accept-Language',
            'x-content-type-options': 'nosniff',
        };
    }

    function render(reference, profile, method) {
        if (method !== 'GET' && method !== 'HEAD') throw new TypeError('Request rejected.');
        const { variant } = resolve(reference, profile);
        return {
            status: 200,
            profile,
            headers: headers(reference, profile),
            body: method === 'HEAD' ? '' : variant.representation,
        };
    }

    function match(reference, profile, candidate) {
        if (!candidate || typeof candidate.tag !== 'string' || typeof candidate.body !== 'string') return false;
        const { variant } = resolve(reference, profile);
        return variant.tag === candidate.tag && variant.representation === candidate.body;
    }

    function digest(reference, profile) {
        return hash(resolve(reference, profile).variant.representation);
    }

    function tag(reference, profile) {
        return resolve(reference, profile).variant.tag;
    }

    return Object.freeze({ create, digest, match, render, tag });
}

module.exports = { createDocumentRepository };
