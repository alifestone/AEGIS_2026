'use strict';

const { createHash } = require('node:crypto');
const { RequestError } = require('../errors');

const VERSION = 1;
const CHANNEL = 'evaluation';
const LIMIT = 530;
const PATTERN = /^[\[\]()!+]+$/;
const VALUES = Object.freeze([
    'start,039595',
    'start,166299',
    'start,245489',
    'start,395950',
    'start,593925',
    'start,609763',
    'start,657277',
    'start,665196',
    'start,728548',
    'start,736467',
    'start,744386',
    'start,807738',
    'start,815657',
    'start,879009',
]);

function selectValue(context) {
    const seed = createHash('sha256')
        .update('jsfbox4:v1\0')
        .update(context.workspaceId)
        .update('\0')
        .update(context.recordId)
        .update('\0')
        .update(String(context.revision))
        .update('\0')
        .update(context.logDigest)
        .digest();
    return VALUES[seed[0] % VALUES.length];
}

function createProofModule(codec, evaluator) {
    function issue(context) {
        const input = selectValue(context);
        return {
            input,
            limit: LIMIT,
            token: codec.seal(CHANNEL, { version: VERSION, ...context, input, limit: LIMIT }),
        };
    }

    function open(token, context) {
        let value;
        try {
            value = codec.open(CHANNEL, token);
        } catch {
            throw new RequestError(400, 'Answer rejected.');
        }
        const expected = selectValue(context);
        if (!value || value.version !== VERSION || value.workspaceId !== context.workspaceId
            || value.recordId !== context.recordId || value.revision !== context.revision
            || value.chain !== context.chain || value.logDigest !== context.logDigest
            || value.input !== expected || value.limit !== LIMIT) {
            throw new RequestError(403, 'Answer rejected.');
        }
        return value;
    }

    async function verify(context, answer) {
        if (!answer || typeof answer !== 'object' || Array.isArray(answer)
            || typeof answer.ticket !== 'string' || typeof answer.source !== 'string') {
            throw new RequestError(400, 'Answer rejected.');
        }
        const ticket = open(answer.ticket, context);
        if (Buffer.byteLength(answer.source) > ticket.limit || !PATTERN.test(answer.source)) {
            throw new RequestError(422, 'Answer rejected.');
        }
        const result = await evaluator.evaluate(answer.source);
        if (result !== ticket.input) throw new RequestError(422, 'Answer rejected.');
        return Object.freeze({ value: ticket.input });
    }

    return Object.freeze({ issue, verify });
}

module.exports = { createProofModule };
