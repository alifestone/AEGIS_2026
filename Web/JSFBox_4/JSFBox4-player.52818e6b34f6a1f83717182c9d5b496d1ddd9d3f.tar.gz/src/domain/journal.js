'use strict';

const { createHash } = require('node:crypto');
const { RequestError } = require('../errors');

const VERSION = 1;
const CHANNEL = Object.freeze({ witness: 'observation', approval: 'approval' });

function hash(value) {
    return createHash('sha256').update(value).digest('base64url');
}

function journalHash(items) {
    return hash(`jsfbox4:v2\0${JSON.stringify(items.map((item) => [
        item.kind,
        item.profile,
        item.tag,
        item.digest,
    ]))}`);
}

function createJournal(codec) {
    function empty() {
        return { items: [], digest: journalHash([]) };
    }

    function append(state, kind, observation) {
        state.journal.items.push({
            kind,
            profile: observation.profile,
            tag: observation.tag,
            digest: hash(observation.body),
        });
        state.journal.digest = journalHash(state.journal.items);
    }

    function hasTrail(state, expected) {
        return state.journal.items.length === expected.length
            && state.journal.items.every((item, index) => item.kind === expected[index]);
    }

    function open(channel, token) {
        try {
            return codec.open(channel, token);
        } catch {
            throw new RequestError(400, 'Credential rejected.');
        }
    }

    function packet(state, position) {
        const items = state.journal.items.slice(0, position);
        const item = items.at(-1);
        if (!item) throw new RequestError(409, 'Sequence rejected.');
        return {
            version: VERSION,
            workspace: state.identity.workspaceId,
            document: state.document.id,
            revision: state.document.revision,
            lineage: state.identity.lineage,
            position,
            journal: journalHash(items),
            ...item,
        };
    }

    function issueWitness(state) {
        return codec.seal(CHANNEL.witness, packet(state, state.journal.items.length));
    }

    function verifyWitness(token, state, position) {
        if (typeof token !== 'string') throw new RequestError(400, 'Credential required.');
        const actual = open(CHANNEL.witness, token);
        const expected = packet(state, position);
        if (JSON.stringify(actual) !== JSON.stringify(expected)) {
            throw new RequestError(403, 'Credential rejected.');
        }
        return actual;
    }

    function issueApproval(state) {
        return codec.seal(CHANNEL.approval, packet(state, 1));
    }

    function verifyApproval(token, state) {
        if (typeof token !== 'string') throw new RequestError(400, 'Credential required.');
        const actual = open(CHANNEL.approval, token);
        const expected = packet(state, 1);
        if (JSON.stringify(actual) !== JSON.stringify(expected)) {
            throw new RequestError(403, 'Credential rejected.');
        }
        return actual;
    }

    function at(state, index) {
        const item = state.journal.items[index];
        if (!item) throw new RequestError(409, 'Sequence rejected.');
        return item;
    }

    function proofContext(state) {
        return Object.freeze({
            workspaceId: state.identity.workspaceId,
            recordId: state.document.id,
            revision: state.document.revision,
            chain: state.identity.lineage,
            logDigest: state.journal.digest,
        });
    }

    return Object.freeze({
        append,
        at,
        digest: hash,
        empty,
        hasTrail,
        issueApproval,
        issueWitness,
        proofContext,
        verifyApproval,
        verifyWitness,
    });
}

module.exports = { createJournal };
