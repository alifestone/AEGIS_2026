'use strict';

const { randomUUID } = require('node:crypto');
const { RequestError } = require('../errors');

const MOVES = Object.freeze({
    queue: Object.freeze({ from: 'draft', to: 'circulating' }),
    observe: Object.freeze({ from: 'circulating', to: 'reviewed' }),
    stage: Object.freeze({ from: 'reviewed', to: 'distributed' }),
    catalog: Object.freeze({ from: 'distributed', to: 'cataloged' }),
    deliver: Object.freeze({ from: 'cataloged', to: 'released' }),
});
const STEPS = Object.freeze({ draft: 0, circulating: 1, reviewed: 2, distributed: 3, cataloged: 4, released: 5 });

function createLifecycle(journal) {
    function create(workspaceId, document) {
        return {
            version: 1,
            identity: { workspaceId, lineage: randomUUID() },
            document,
            stage: 'draft',
            step: STEPS.draft,
            cache: null,
            journal: journal.empty(),
        };
    }

    function requireStage(state, expected) {
        if (state.stage !== expected || state.step !== STEPS[expected]) {
            throw new RequestError(409, 'Sequence rejected.');
        }
    }

    function advance(state, move) {
        const transition = MOVES[move];
        if (!transition || state.stage !== transition.from) {
            throw new RequestError(409, 'Sequence rejected.');
        }
        state.stage = transition.to;
        state.step = STEPS[transition.to];
    }

    function summary(state) {
        return Object.freeze({
            record: Object.freeze({ id: state.document.id, revision: state.document.revision }),
            progress: Object.freeze({ stage: state.stage, step: state.step }),
            activity: Object.freeze(state.journal.items.map((item) => item.kind)),
        });
    }

    return Object.freeze({ advance, create, requireStage, summary });
}

module.exports = { createLifecycle };
