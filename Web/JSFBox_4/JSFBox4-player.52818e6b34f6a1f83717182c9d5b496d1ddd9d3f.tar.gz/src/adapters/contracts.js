'use strict';

const { INPUT_LIMITS } = require('../config/policies');
const { RequestError } = require('../errors');

const DENIED_HEADERS = Object.freeze([
    'if-match',
    'if-modified-since',
    'if-none-match',
    'if-range',
    'if-unmodified-since',
    'range',
]);

function bodyObject(value) {
    return value && typeof value === 'object' && !Array.isArray(value) ? value : {};
}

const INPUTS = Object.freeze({
    empty: () => ({}),
    lease: (body) => ({ lease: body.state }),
    observation: (body) => ({
        lease: body.state,
        observation: { credential: body.receipt, representation: body.body },
    }),
    approval: (body) => ({
        lease: body.state,
        credentials: { primary: body.permit },
    }),
    submission: (body) => ({
        lease: body.state,
        credentials: {
            primary: body.permit,
            checkpoint: body.checkpoint,
            terminal: body.receipt,
        },
        artifact: { representation: body.body, answer: body.answer },
    }),
    projection: (body) => ({ lease: body.state, query: { path: body.path } }),
    export: (body) => ({ lease: body.state, query: { format: body.format } }),
});

const OUTPUTS = Object.freeze({
    session: (result) => ({ state: result.lease, record: result.reference }),
    progress: (result) => ({ state: result.lease, status: { step: result.step } }),
    approval: (result) => ({ permit: result.credential }),
    distribution: (result) => ({
        state: result.lease,
        checkpoint: result.checkpoint,
        response: { status: result.upstream.status, body: null },
    }),
    decision: (result) => result.kind === 'accepted'
        ? { status: 'accepted' }
        : { status: 'complete', flag: result.value },
    projection: (result) => ({ value: result.value }),
    export: (result) => ({ format: result.format, data: result.data }),
});

function decode(name, value) {
    const decoder = INPUTS[name];
    if (!decoder) throw new TypeError('Contract rejected.');
    return decoder(bodyObject(value));
}

function encode(name, value) {
    const encoder = OUTPUTS[name];
    if (!encoder) throw new TypeError('Contract rejected.');
    return encoder(value);
}

function headerCount(request, name) {
    const wanted = name.toLowerCase();
    let count = 0;
    for (let index = 0; index < request.rawHeaders.length; index += 2) {
        if (request.rawHeaders[index].toLowerCase() === wanted) count += 1;
    }
    return count;
}

function normalizeResource(request, route) {
    if (request.method !== 'GET' && request.method !== 'HEAD') {
        throw new RequestError(404, 'Not found.');
    }
    if (Object.keys(request.query).length > 0 || headerCount(request, 'x-jsfbox-state') !== 1) {
        throw new RequestError(400, 'Request rejected.');
    }
    for (const name of DENIED_HEADERS) {
        if (request.headers[name] !== undefined) throw new RequestError(400, 'Request rejected.');
    }
    const metadataOnly = request.method === 'HEAD';
    const control = request.get('cache-control');
    if (metadataOnly) {
        if (!control || control.trim().toLowerCase() !== 'no-cache') {
            throw new RequestError(400, 'Request rejected.');
        }
    } else if (control || request.get('pragma')) {
        throw new RequestError(400, 'Request rejected.');
    }
    const language = request.get('accept-language') || 'en';
    if (Buffer.byteLength(language) > INPUT_LIMITS.language) {
        throw new RequestError(400, 'Request rejected.');
    }
    return {
        lease: request.get('x-jsfbox-state'),
        family: route.family,
        kind: metadataOnly ? 'metadata' : 'representation',
        method: request.method,
        query: { url: route.path, method: 'GET', headers: { 'accept-language': language } },
    };
}

function sendResource(response, result, method) {
    response.status(200).set(result.exchange.headers);
    response.set('cache-status', result.cache === 'hit' ? 'jsfbox; hit' : 'jsfbox; fwd=uri-miss');
    response.set('x-jsfbox-state', result.lease);
    if (result.witness) response.set('x-jsfbox-receipt', result.witness);
    if (result.proof) {
        response.set('x-jsfbox-ticket', result.proof.token);
        response.set('x-jsfbox-limit', String(result.proof.limit));
        response.set('x-jsfbox-input', result.proof.input);
    }
    return method === 'HEAD' ? response.end() : response.send(result.exchange.body);
}

module.exports = { decode, encode, normalizeResource, sendResource };
