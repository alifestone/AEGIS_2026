'use strict';

const express = require('express');
const { RequestError } = require('../errors');

const VERSION = 1;
const CHANNEL = 'origin-dispatch';
const INTERNAL_PATH = '/runtime/representation';

function isLocal(address) {
    return address === '127.0.0.1' || address === '::1' || address === '::ffff:127.0.0.1';
}

function createOriginApp(codec, documents) {
    const app = express();
    app.disable('x-powered-by');
    app.set('etag', false);
    app.all(INTERNAL_PATH, (request, response) => {
        if (!isLocal(request.socket.remoteAddress)
            || (request.method !== 'GET' && request.method !== 'HEAD')) {
            return response.status(404).type('text/plain').send('Not found.');
        }
        let dispatch;
        try {
            dispatch = codec.open(CHANNEL, request.get('x-jsfbox-local'));
        } catch {
            throw new RequestError(400, 'Request rejected.');
        }
        if (!dispatch || dispatch.version !== VERSION || dispatch.method !== request.method
            || !dispatch.reference || typeof dispatch.profile !== 'string') {
            throw new RequestError(400, 'Request rejected.');
        }
        const source = documents.render(dispatch.reference, dispatch.profile, request.method);
        response.status(source.status).set(source.headers);
        return request.method === 'HEAD' ? response.end() : response.send(source.body);
    });
    app.use((_request, response) => response.status(404).type('text/plain').send('Not found.'));
    app.use((error, _request, response, _next) => {
        if (response.headersSent) return;
        return response.status(400).type('text/plain').send('Request rejected.');
    });
    return app;
}

function originUrl(port) {
    return new URL(INTERNAL_PATH, `http://127.0.0.1:${port}`).toString();
}

function createOriginClient(portOf, codec) {
    return async function resolve({ reference, profile, method }) {
        let response;
        try {
            response = await fetch(originUrl(portOf()), {
                method,
                headers: {
                    'x-jsfbox-local': codec.seal(CHANNEL, {
                        version: VERSION,
                        reference,
                        profile,
                        method,
                    }),
                },
            });
        } catch {
            throw new RequestError(503, 'Request rejected.');
        }
        if (response.status !== 200) throw new RequestError(503, 'Request rejected.');
        return {
            status: response.status,
            profile,
            headers: Object.fromEntries(response.headers.entries()),
            body: method === 'HEAD' ? '' : await response.text(),
        };
    };
}

function createDirectOrigin(documents) {
    return ({ reference, profile, method }) => Promise.resolve(documents.render(reference, profile, method));
}

module.exports = { createDirectOrigin, createOriginApp, createOriginClient };
