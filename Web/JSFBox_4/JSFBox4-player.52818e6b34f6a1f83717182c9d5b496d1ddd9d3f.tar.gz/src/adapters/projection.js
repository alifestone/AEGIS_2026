'use strict';

const { INPUT_LIMITS } = require('../config/policies');

const BLOCKED = new Set(['__proto__', 'prototype', 'constructor']);

function publicTree(state) {
    const root = Object.create(null);
    root.record = Object.assign(Object.create(null), {
        id: state.document.id,
        revision: state.document.revision,
    });
    root.availability = Object.assign(Object.create(null), {
        preview: true,
        formats: ['json', 'text'],
    });
    return root;
}

function select(root, selector) {
    if (typeof selector !== 'string' || Buffer.byteLength(selector) > INPUT_LIMITS.selector) return null;
    const parts = selector.split('.');
    if (parts.length === 0 || parts.length > 4
        || parts.some((part) => part.length === 0 || BLOCKED.has(part))) {
        return null;
    }
    let cursor = root;
    for (const part of parts) {
        if (!cursor || typeof cursor !== 'object' || !Object.hasOwn(cursor, part)) return null;
        cursor = Reflect.get(cursor, part);
    }
    return cursor === undefined ? null : cursor;
}

function createProjectionModule() {
    function project({ state, dto }) {
        return { result: { value: select(publicTree(state), dto.query.path) } };
    }

    function exportRecord({ state, dto }) {
        const format = dto.query.format === 'text' ? 'text' : 'json';
        const tree = publicTree(state);
        if (format === 'text') {
            return { result: { format, data: `record=${tree.record.id}\nrevision=${tree.record.revision}` } };
        }
        return { result: { format, data: JSON.stringify(tree) } };
    }

    return Object.freeze({ exportRecord, project });
}

module.exports = { createProjectionModule };
