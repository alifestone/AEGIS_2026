'use strict';

const express = require('express');
const { CONTROL_ROUTES, RESOURCE_ROUTES } = require('../config/routes');
const { controlBinding, resourceBinding } = require('../config/bindings');
const { decode, encode, normalizeResource, sendResource } = require('./contracts');
const { RequestError } = require('../errors');

const JSON_LIMIT = '16kb';

function asyncRoute(handler) {
    return (request, response, next) => Promise.resolve(handler(request, response, next)).catch(next);
}

function createHttpApp(options) {
    const app = express();
    app.disable('x-powered-by');
    app.set('etag', false);
    app.use('/api', (_request, response, next) => {
        response.set('cache-control', 'no-store');
        next();
    });
    app.use(express.json({ limit: JSON_LIMIT, strict: true, type: 'application/json' }));
    app.use(express.static(options.staticRoot, { index: 'index.html', fallthrough: true }));

    app.get('/health', (_request, response) => response.json({ status: 'ok' }));

    for (const route of CONTROL_ROUTES) {
        app.post(route.path, asyncRoute(async (request, response) => {
            const binding = controlBinding(route.name);
            const input = decode(binding.input, request.body);
            const result = await options.broker.execute(binding.binding, input);
            return response.status(binding.status || 200).json(encode(binding.output, result));
        }));
    }

    for (const route of RESOURCE_ROUTES) {
        app.all(route.path, asyncRoute(async (request, response) => {
            const binding = resourceBinding(route.name);
            const input = normalizeResource(request, { ...route, ...binding });
            const result = await options.resources.handle(input);
            return sendResource(response, result, request.method);
        }));
    }

    app.use((_request, response) => response.status(404).type('text/plain').send('Not found.'));
    app.use((error, _request, response, _next) => {
        if (response.headersSent) return;
        if (error instanceof RequestError) {
            return response.status(error.status).json({ error: error.message });
        }
        if (error && (error.type === 'entity.parse.failed' || error.type === 'entity.too.large')) {
            return response.status(400).json({ error: 'Request rejected.' });
        }
        return response.status(500).json({ error: 'Internal error.' });
    });
    return app;
}

module.exports = { createHttpApp };
