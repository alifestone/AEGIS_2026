'use strict';

(() => {
    let sessionLease = null;
    let approval = null;
    let openedDocument = null;
    let step = 0;
    let pending = false;

    const screen = document.getElementById('output');
    const recordId = document.getElementById('record-id');
    const revision = document.getElementById('revision');
    const indicator = document.getElementById('status');
    const stepNumber = document.getElementById('step-number');
    const progressBar = document.getElementById('progress-fill');
    const activity = document.getElementById('activity-label');
    const cards = [...document.querySelectorAll('.operation-card')];
    const buttons = [
        document.getElementById('new'),
        document.getElementById('begin'),
        document.getElementById('open'),
        document.getElementById('confirm'),
        document.getElementById('submit'),
    ];

    async function send(path, data = {}) {
        const reply = await fetch(path, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data),
        });
        const result = await reply.json();
        if (!reply.ok) throw new Error(result.error || `HTTP ${reply.status}`);
        return result;
    }

    async function load() {
        const reply = await fetch('/w/current', {
            headers: {
                'Accept-Language': 'en',
                'X-JSFBox-State': sessionLease,
            },
        });
        const text = await reply.text();
        if (!reply.ok) {
            let message = `HTTP ${reply.status}`;
            try {
                message = JSON.parse(text).error || message;
            } catch {}
            throw new Error(message);
        }
        const next = reply.headers.get('x-jsfbox-state');
        const stamp = reply.headers.get('x-jsfbox-receipt');
        if (!next || !stamp) throw new Error('Response rejected.');
        return { lease: next, stamp, text };
    }

    function render(value, tone = '') {
        screen.classList.add('is-updating');
        window.setTimeout(() => {
            screen.textContent = JSON.stringify(value, null, 2);
            screen.classList.remove('is-updating', 'is-error', 'is-success');
            if (tone) screen.classList.add(`is-${tone}`);
        }, 90);
    }

    function setIndicator(value, tone) {
        indicator.textContent = value;
        indicator.dataset.tone = tone;
    }

    function setStep(next) {
        step = next;
        document.body.dataset.progress = String(step);
        stepNumber.textContent = String(step).padStart(2, '0');
        progressBar.style.width = `${step * 20}%`;
        cards.forEach((card, index) => {
            const position = index + 1;
            card.classList.toggle('is-complete', position <= step);
            card.classList.toggle('is-active', step < 5 && position === step + 1);
            if (position === step + 1) card.setAttribute('aria-current', 'step');
            else card.removeAttribute('aria-current');
        });
        updateButtons();
    }

    function updateButtons() {
        const enabled = [true, step === 1, step === 2, step === 3, step === 4];
        buttons.forEach((button, index) => {
            button.disabled = pending || !enabled[index];
        });
    }

    async function perform(button, label, operation) {
        if (pending) return;
        pending = true;
        document.body.dataset.busy = 'true';
        activity.textContent = label;
        updateButtons();
        try {
            await operation();
        } catch (error) {
            render({ error: error.message }, 'error');
            indicator.dataset.tone = 'error';
            activity.textContent = 'OPERATION REJECTED';
        } finally {
            pending = false;
            document.body.dataset.busy = 'false';
            updateButtons();
            button.focus({ preventScroll: true });
        }
    }

    buttons[0].addEventListener('click', () => perform(buttons[0], 'CREATING RECORD', async () => {
        const result = await send('/api/session');
        sessionLease = result.state;
        approval = null;
        openedDocument = null;
        recordId.textContent = result.record.id;
        revision.textContent = String(result.record.revision);
        setIndicator('created', 'active');
        setStep(1);
        activity.textContent = 'RECORD CREATED';
        render({ record: result.record }, 'success');
    }));

    buttons[1].addEventListener('click', () => perform(buttons[1], 'STARTING WORKFLOW', async () => {
        if (!sessionLease) throw new Error('Create a record first.');
        const result = await send('/api/approve', { state: sessionLease });
        sessionLease = result.state;
        approval = null;
        openedDocument = null;
        setIndicator('started', 'active');
        setStep(2);
        activity.textContent = 'WORKFLOW STARTED';
        render(result.status, 'success');
    }));

    buttons[2].addEventListener('click', () => perform(buttons[2], 'OPENING RECORD', async () => {
        if (!sessionLease) throw new Error('Create a record first.');
        openedDocument = await load();
        sessionLease = openedDocument.lease;
        setIndicator('opened', 'active');
        setStep(3);
        activity.textContent = 'RECORD OPENED';
        render(JSON.parse(openedDocument.text), 'success');
    }));

    buttons[3].addEventListener('click', () => perform(buttons[3], 'CONFIRMING RECORD', async () => {
        if (!sessionLease || !openedDocument) throw new Error('Open the record first.');
        const result = await send('/api/confirm', {
            state: sessionLease,
            receipt: openedDocument.stamp,
            body: openedDocument.text,
        });
        approval = result.permit;
        setIndicator('confirmed', 'active');
        setStep(4);
        activity.textContent = 'RECORD CONFIRMED';
        render({ status: 'confirmed' }, 'success');
    }));

    buttons[4].addEventListener('click', () => perform(buttons[4], 'PUBLISHING RECORD', async () => {
        if (!sessionLease || !approval || !openedDocument) {
            throw new Error('Complete the previous operations first.');
        }
        const result = await send('/api/publish', {
            state: sessionLease,
            permit: approval,
            body: openedDocument.text,
        });
        setIndicator(result.status, 'complete');
        setStep(5);
        activity.textContent = 'PUBLICATION ACCEPTED';
        render(result, 'success');
    }));

    setStep(0);
})();
