
import json
import time
from utils.base64 import Base64
from utils.dsa import DSA
from utils.telepathy import encrypt
import services
import config


def generate_token(account: str, role: str, curve: str, hash: str, session_uuid: str | None = None) -> str:
    if (session_uuid):
        session = services.get_session(session_uuid)
        if not session:
            raise Exception("Session not found")
        if session.count >= 3:
            services.delete_session(session_uuid)
            raise Exception("Session refresh limit exceeded")
        b64seed = session.b64seed
        k = session.k
        d = session.d
        v = session.v
        w = session.w
    else:
        N = config.CURVE[curve]["n"]
        b64seed = config.b64seed(N)
        k = int.from_bytes(config.k().encode(), "big")
        d = config.d(N)
        v = config.v(N)
        w = config.w(N)

    if (curve not in config.CURVE.keys()):
        raise Exception("Invalid curve")

    if (hash not in config.HASH.keys()):
        raise Exception("Invalid hash function")

    encoder = Base64(seed=b64seed)
    header = {"curve": curve, "hash": hash}
    payload = {"account": account, "role": encoder.encode(role), "timestamp": int(time.time())}

    header_json = json.dumps(header, separators=(",", ":"))
    payload_json = json.dumps(payload, separators=(",", ":"))

    signer = DSA(curve=curve, hash=hash, d=d, k=k, v=v, w=w)
    r, s = signer.sign(f'{header_json}.{payload_json}')
    k = signer.k
    signature_json = json.dumps({"r": r, "s": s}, separators=(",", ":"))

    if (session_uuid):
        services.update_session(session_uuid, b64seed, k, d, v, w, session.count + 1)
    else:
        session_uuid = config.get_uuid()
        services.add_session(session_uuid, b64seed, k, d, v, w, 0)

    header_b64 = encoder.encode(header_json)
    payload_b64 = encoder.encode(payload_json)
    signature_b64 = encoder.encode(signature_json)

    return f"{session_uuid}.{header_b64}.{payload_b64}.{signature_b64}"


def validate_token(token: str) -> tuple[bool, str | None, str | None, str]:
    try:
        session_uuid, header_b64, payload_b64, signature_b64 = token.split('.')
        session = services.get_session(session_uuid)
        if not session:
            return False, None, None, "Session not found"

        encoder = Base64(seed=session.b64seed)
        header_json = encoder.decode(header_b64)
        header = json.loads(header_json)

        if header["curve"] not in config.CURVE.keys() or header["hash"] not in config.HASH.keys():
            return False, None, None, "Invalid header"

        payload_json = encoder.decode(payload_b64)
        signature_json = encoder.decode(signature_b64)

        signature = json.loads(signature_json)

        verifier = DSA(curve=header["curve"], hash=header["hash"], d=session.d, k=session.k, v=session.v, w=session.w)
        is_valid = verifier.verify(f'{header_json}.{payload_json}', signature["r"], signature["s"])
        return is_valid, session_uuid, header_json, payload_json
    except Exception:
        return False, None, None, "Invalid Token"


def telepathy(session_uuid: str) -> bytes:
    services.delete_session(session_uuid)
    iv = config.iv()
    return iv + encrypt(config.pt().encode(), config.key(), iv)
