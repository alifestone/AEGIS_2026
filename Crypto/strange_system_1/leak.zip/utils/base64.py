import re
import random


class Base64:
    def __init__(self, seed: int):
        random.seed(seed)
        chars = list('ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/')
        self.base64_chars = ''.join(random.sample(chars, len(chars)))
        self.padding_char = '='

    def encode(self, data: str) -> str:
        try:
            if len(data) == 0:
                raise Exception("Empty data")

            binary_data = ''.join(format(ord(char), '08b') for char in data)
            while len(binary_data) % 6 != 0:
                binary_data += '0'

            encoded_data = ''
            for i in range(0, len(binary_data), 6):
                index = int(binary_data[i:i+6], 2)
                encoded_data += self.base64_chars[index]

            padding = (3 - (len(data) % 3)) % 3
            encoded_data += self.padding_char * padding

            return encoded_data
        except Exception as e:
            raise Exception(e)

    def decode(self, encoded_data: str) -> str:
        try:
            if len(encoded_data) == 0:
                raise Exception("Empty data")

            if re.match(r'^[A-Za-z0-9+/]+={0,2}$', encoded_data) == None:
                raise Exception("Invalid base64 data")

            binary_data = ''
            for char in encoded_data:
                if char == self.padding_char:
                    binary_data = binary_data[:-2]
                    continue
                index = self.base64_chars.index(char)
                binary_data += format(index, '06b')

            if (len(binary_data) % 8 != 0):
                raise Exception("Invalid base64 data")

            data = ''
            for i in range(0, len(binary_data), 8):
                data += chr(int(binary_data[i:i+8], 2))

            return data
        except Exception as e:
            raise Exception(e)
