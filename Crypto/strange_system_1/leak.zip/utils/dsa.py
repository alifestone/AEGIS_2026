import config


class DSA:
    def __init__(self, curve: str, hash: str, d: int, k: int, v: int, w: int):
        self.HASH = config.HASH[hash]
        self.CURVE = config.CURVE[curve]

        self.p = self.CURVE["p"]
        self.a = self.CURVE["a"]
        self.b = self.CURVE["b"]
        self.G = self.CURVE["G"]
        self.n = self.CURVE["n"]

        self.d = d
        self.k = k
        self.v = v
        self.w = w

    def add(self, p: tuple[int, int], q: tuple[int, int]) -> tuple[int, int]:
        try:
            if p == (0, 0):
                return q
            if q == (0, 0):
                return p
            if p[0] == q[0] and p[1] != q[1]:
                return (0, 0)
            if p != q:
                l = ((q[1] - p[1]) * pow(q[0] - p[0], -1, self.p)) % self.p
            else:
                if p[1] == 0:
                    return (0, 0)
                l = ((3 * p[0] * p[0] + self.a) * pow(2 * p[1], -1, self.p)) % self.p
            x = (l * l - p[0] - q[0]) % self.p
            y = (l * (p[0] - x) - p[1]) % self.p
            return (x, y)
        except Exception as e:
            raise Exception(e)

    def mul(self, k: int, p: tuple[int, int]) -> tuple[int, int]:
        try:
            q = (0, 0)
            while k > 0:
                if k & 1:
                    q = self.add(q, p)
                p = self.add(p, p)
                k >>= 1
            return q
        except Exception as e:
            raise Exception(e)

    def sign(self, message: str) -> tuple[int, int]:
        try:
            m_hash = int.from_bytes(self.HASH(message).digest(), 'big')
            self.k = (self.v * self.k + self.w) % self.n
            P = self.mul(self.k, self.G)
            r = P[0] % self.n
            s = ((m_hash + r * self.d) * pow(self.k, -1, self.n)) % self.n
            return r, s
        except Exception as e:
            raise Exception(e)

    def verify(self, message: str, r: int, s: int) -> bool:
        try:
            m_hash = int.from_bytes(self.HASH(message).digest(), 'big')
            w = pow(s, -1, self.n)
            u1 = (m_hash * w) % self.n
            u2 = (r * w) % self.n
            P = self.add(self.mul(u1, self.G), self.mul(u2, self.mul(self.d, self.G)))
            return r == P[0] % self.n
        except Exception as e:
            raise Exception(e)
