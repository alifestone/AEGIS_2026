import uvicorn
from uvicorn.config import LOGGING_CONFIG

from fastapi import FastAPI, HTTPException, Header, Response
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager
from models import *
import services
import utils
import json


@asynccontextmanager
async def lifespan(app: FastAPI):
    print("Initializing database...")
    services.initialize_database()
    print("Database initialized.")
    print("Starting server...")
    yield
    print("Shutting down server...")

app = FastAPI(lifespan=lifespan)
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])


@app.get("/")
def index():
    return "Hello, World!"


@app.post("/login")
def login(data: LoginRequest):
    try:
        user = services.get_user(data.account, data.password)
        if not user:
            raise HTTPException(status_code=401, detail="Invalid account or password")
        return utils.generate_token(user.account, user.role, data.curve, data.hash)
    except HTTPException as e:
        raise e
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.post("/refresh")
def refresh(token: str = Header()):
    try:
        is_valid, session_uuid, header, payload = utils.validate_token(token)
        if is_valid and session_uuid is not None:
            header_dict = json.loads(header)
            payload_dict = json.loads(payload)
            return utils.generate_token(payload_dict["account"], payload_dict["role"], header_dict["curve"], header_dict["hash"], session_uuid)
        else:
            raise HTTPException(status_code=401, detail=payload)
    except HTTPException as e:
        raise e
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.get("/telepathy")
def telepathy(token: str = Header()) -> Response:
    try:
        is_valid, session_uuid, _, payload = utils.validate_token(token)
        if is_valid and session_uuid is not None:
            payload_dict = json.loads(payload)
            if payload_dict["role"] != "medium":
                raise HTTPException(status_code=403, detail="Forbidden: medium only")
            return Response(content=utils.telepathy(session_uuid), media_type="application/octet-stream", headers={"Content-Disposition": "attachment; filename=telepathy"})
        else:
            raise HTTPException(status_code=401, detail="Invalid payload")
    except HTTPException as e:
        raise e
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


if __name__ == "__main__":
    log_config = LOGGING_CONFIG
    log_config["formatters"]["default"]["format"] = "[%(asctime)s] %(levelname)s: %(message)s"
    log_config["formatters"]["access"]["format"] = "[%(asctime)s] %(levelname)s: %(client_addr)s - '%(request_line)s' %(status_code)s"
    log_config["formatters"]["default"]["datefmt"] = "%Y-%m-%d %H:%M:%S"
    log_config["formatters"]["access"]["datefmt"] = "%Y-%m-%d %H:%M:%S"

    uvicorn.run("main:app", host="0.0.0.0", port=8000, use_colors=False, log_config=log_config)
